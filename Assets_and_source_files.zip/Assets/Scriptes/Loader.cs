﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class Loader : MonoBehaviour
{
    public GameObject gameManager;
    public GameObject GM;
    public GameObject interfaces;
    public InputField raw;
    public InputField columns;
    EventSystem system;

    // Start is called before the first frame update
    void Awake()
    {
        system = EventSystem.current;
        /* if (GameManager.instance == null)
         {
             GM = Instantiate(gameManager);
         }*/
    }
    public void StartGame()
    {
        
        if (GameManager.instance == null)
        {

            interfaces.SetActive(false);
            GM = Instantiate(gameManager);
            GM.GetComponent<BoardManager>().rows = int.Parse(raw.text);
            GM.GetComponent<BoardManager>().columns = int.Parse(columns.text);
            interfaces.SetActive(false);
        }
    }
    public void Update()
    {

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            Selectable next = system.currentSelectedGameObject.GetComponent<Selectable>().FindSelectableOnDown();

            if (next != null)
            {

                InputField inputfield = next.GetComponent<InputField>();
                if (inputfield != null) inputfield.OnPointerClick(new PointerEventData(system));  //if it's an input field, also set the text caret

                system.SetSelectedGameObject(next.gameObject, new BaseEventData(system));
            }
            //else Debug.Log("next nagivation element not found");

        }
    }
}
