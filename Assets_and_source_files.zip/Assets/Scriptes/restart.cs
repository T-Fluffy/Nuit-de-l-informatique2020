﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class restart : MonoBehaviour
{
    public GameObject AboutusUI;
    public GameObject PauseUI;

    // Start is called before the first frame update
    public void AboutUS()
    {
       AboutusUI.SetActive(true);
       PauseUI.SetActive(false);
    }
    public void pauseinterface(){
        AboutusUI.SetActive(false);
       PauseUI.SetActive(true);
    } 
    public void startGame()
    {
        SceneManager.LoadScene(1);
    }
    public void QuitGame()
    {
        Application.Quit();
    }
    // Update is called once per frame
   
}
